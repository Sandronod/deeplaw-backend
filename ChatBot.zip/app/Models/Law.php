<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Law extends Model
{
    protected $connection = 'pgvector';

    protected $fillable = [
        'matsne_id',
        'title',
        'document_num',
        'category',
        'status',
        'adopted_at',
        'source_url',
    ];

    protected $casts = [
        'adopted_at' => 'date',
    ];

    public function articles(): HasMany
    {
        return $this->hasMany(LawArticle::class);
    }
}
