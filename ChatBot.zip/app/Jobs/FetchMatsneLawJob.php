<?php

namespace App\Jobs;

use App\Models\Law;
use App\Models\LawArticle;
use App\Services\AI\EmbedCacheService;
use App\Services\Matsne\ExternalSourceRateLimiter;
use App\Services\Matsne\FetchLockService;
use App\Services\Matsne\MatsneFetchService;
use App\Services\Matsne\MatsneHtmlParserService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FetchMatsneLawJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 180;

    /**
     * Retry after 30 seconds on failure (respects rate limit).
     */
    public int $backoff = 30;

    public function __construct(
        public readonly int    $matsneId,
        public readonly string $lawName = '',
        public readonly bool   $forceRefresh = false,
    ) {}

    public function handle(
        MatsneFetchService      $fetcher,
        MatsneHtmlParserService $parser,
        EmbedCacheService       $embedCache,
        FetchLockService        $lockService,
        ExternalSourceRateLimiter $rateLimiter,
    ): void {
        // ── 1. Acquire exclusive fetch lock ───────────────────────────────────
        $lock = $lockService->acquire($this->matsneId);

        if (!$lock) {
            Log::info('FetchMatsneLawJob: skipped — lock held', ['matsne_id' => $this->matsneId]);
            return;
        }

        try {
            // Skip if already in DB (unless force refresh requested)
            if (!$this->forceRefresh) {
                $exists = DB::connection('pgvector')
                    ->table('laws')
                    ->where('matsne_id', (string) $this->matsneId)
                    ->exists();

                if ($exists) {
                    Log::info('FetchMatsneLawJob: already indexed', ['matsne_id' => $this->matsneId]);
                    return;
                }
            }

            // ── 2. Rate-limited fetch ─────────────────────────────────────────
            $html = $rateLimiter->throttle('matsne.gov.ge', function () use ($fetcher) {
                return $fetcher->fetchHtml($this->matsneId);
            });

            // ── 3. Parse ──────────────────────────────────────────────────────
            $parsed = $parser->parse($html, $this->matsneId);

            if (empty($parsed['articles'])) {
                Log::warning('FetchMatsneLawJob: no articles parsed', ['matsne_id' => $this->matsneId]);
                return;
            }

            // ── 4. Upsert law ─────────────────────────────────────────────────
            $law = Law::on('pgvector')->updateOrCreate(
                ['matsne_id' => (string) $this->matsneId],
                [
                    'title'      => $parsed['title'] ?: ($this->lawName ?: "კანონი #{$this->matsneId}"),
                    'category'   => 'კანონი',
                    'status'     => 'active',
                    'source_url' => "https://matsne.gov.ge/ka/document/view/{$this->matsneId}/0",
                ]
            );

            // ── 5. Create new version ─────────────────────────────────────────
            // Mark previous versions as non-current
            DB::connection('pgvector')
                ->table('law_versions')
                ->where('law_id', $law->id)
                ->update(['is_current' => false]);

            $versionId = DB::connection('pgvector')->table('law_versions')->insertGetId([
                'law_id'        => $law->id,
                'version_date'  => now()->toDateString(),
                'version_label' => now()->format('Y-m-d') . ' ვერსია',
                'is_current'    => true,
                'fetched_at'    => now(),
            ]);

            DB::connection('pgvector')
                ->table('laws')
                ->where('id', $law->id)
                ->update(['current_version_id' => $versionId]);

            // ── 6. Embed + save articles ──────────────────────────────────────
            // Remove old articles
            $law->articles()->delete();

            $texts = array_map(fn($a) => trim(
                ($a['article_num'] ? $a['article_num'] . '. ' : '') . $a['content']
            ), $parsed['articles']);

            $embeddings = $embedCache->embedBatch($texts);

            DB::connection('pgvector')->transaction(function () use ($law, $parsed, $embeddings, $versionId) {
                foreach ($parsed['articles'] as $i => $article) {
                    $record = LawArticle::create([
                        'law_id'          => $law->id,
                        'law_version_id'  => $versionId,
                        'article_num'     => $article['article_num']   ?? null,
                        'article_title'   => $article['article_title'] ?? null,
                        'content'         => $article['content'],
                        'chunk_index'     => $i,
                    ]);

                    if (!empty($embeddings[$i])) {
                        $vec = '[' . implode(',', $embeddings[$i]) . ']';
                        DB::connection('pgvector')->statement(
                            'UPDATE law_articles SET embedding = :emb::vector WHERE id = :id',
                            ['emb' => $vec, 'id' => $record->id]
                        );
                    }
                }
            });

            // Invalidate hot cache for this law
            $this->invalidateCache();

            Log::info('FetchMatsneLawJob: done', [
                'matsne_id'     => $this->matsneId,
                'law_id'        => $law->id,
                'version_id'    => $versionId,
                'article_count' => count($parsed['articles']),
            ]);

        } finally {
            $lock->release();
            $lockService->unmarkQueued($this->matsneId);
        }
    }

    public function failed(\Throwable $e): void
    {
        Log::error('FetchMatsneLawJob: failed', [
            'matsne_id' => $this->matsneId,
            'error'     => $e->getMessage(),
            'attempt'   => $this->attempts(),
        ]);

        app(FetchLockService::class)->unmarkQueued($this->matsneId);
    }

    private function invalidateCache(): void
    {
        // Invalidate any cached retrieval results that might be stale.
        // Since we use md5(query+limit) keys we can't enumerate them,
        // but next requests will simply miss and re-query the DB.
        // For hot laws, the new result will be cached on first access.
    }
}
