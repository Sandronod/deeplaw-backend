<?php

namespace App\Services\Legal;

use App\DTOs\LawResult;
use App\DTOs\SourcePlan;

/**
 * Assembles a unified evidence structure from domestic cases and law articles.
 * Returns a structured array consumed by OpenAILegalAnswerService.
 */
class HybridEvidenceBuilderService
{
    /**
     * @param  array      $domesticDecisions  Enriched decision arrays from LegalCaseRetrieverService
     * @param  LawResult[] $lawResults         From LawRetrieverService
     * @param  SourcePlan  $plan
     * @return array{law: array, domestic_cases: array, summary: string}
     */
    public function build(
        array      $domesticDecisions,
        array      $lawResults,
        SourcePlan $plan,
    ): array {
        $evidence = [
            'law'            => [],
            'domestic_cases' => [],
            'summary'        => '',
        ];

        if ($plan->useLaw && !empty($lawResults)) {
            $evidence['law'] = array_map(fn(LawResult $r) => [
                'law_id'        => $r->lawId,
                'title'         => $r->title,
                'article_num'   => $r->articleNum,
                'article_title' => $r->articleTitle,
                'excerpt'       => $r->excerpt,
                'similarity'    => $r->similarity,
                'url'           => $r->sourceUrl,
            ], $lawResults);
        }

        if ($plan->useDomestic && !empty($domesticDecisions)) {
            $evidence['domestic_cases'] = $domesticDecisions;
        }

        $evidence['summary'] = $this->buildSummary($evidence);

        return $evidence;
    }

    /**
     * Builds a one-line summary for logging/debugging.
     */
    private function buildSummary(array $evidence): string
    {
        $parts = [];
        if (!empty($evidence['law'])) {
            $parts[] = count($evidence['law']) . ' კანონის მუხლი';
        }
        if (!empty($evidence['domestic_cases'])) {
            $parts[] = count($evidence['domestic_cases']) . ' სასამართლო გადაწყვეტილება';
        }
        return empty($parts) ? 'evidence not found' : implode(' + ', $parts);
    }
}
