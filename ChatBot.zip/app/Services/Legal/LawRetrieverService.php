<?php

namespace App\Services\Legal;

use App\DTOs\LawResult;
use App\Jobs\FetchMatsneLawJob;
use App\Services\Matsne\FetchLockService;
use App\Services\Matsne\MatsneFetchService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class LawRetrieverService
{
    private const VECTOR_THRESHOLDS = [0.60, 0.45, 0.35];
    private const CHUNK_LIMIT       = 40;
    private const CACHE_TTL         = 3600; // 1 hour hot cache

    public function __construct(
        private readonly MatsneFetchService $matsne,
        private readonly FetchLockService   $fetchLock,
    ) {}

    /**
     * Deterministic-first law retrieval.
     *
     * Priority:
     *   1. Exact law title match      → all articles of that law
     *   2. Article number match       → "მუხლი 37" exact
     *   3. Keyword search (ILIKE)     → article content
     *   4. Vector embedding           → semantic fallback
     *
     * Results are hot-cached in Redis for 1 hour.
     *
     * @param  array  $embedding  3072-dim vector
     * @param  string $rawQuery   Original user query
     * @param  int    $limit      Max results
     * @return LawResult[]
     */
    public function retrieve(array $embedding, string $rawQuery, int $limit = 5): array
    {
        $cacheKey = 'law_retrieval:' . md5($rawQuery . $limit);

        // Check cache — but never cache empty results (law may be fetching in background)
        $cached = Cache::get($cacheKey);
        if ($cached !== null && !empty($cached)) {
            return $cached;
        }

        $results = $this->doRetrieve($embedding, $rawQuery, $limit);

        if (!empty($results)) {
            Cache::put($cacheKey, $results, self::CACHE_TTL);
        }

        return $results;
    }

    private function doRetrieve(array $embedding, string $rawQuery, int $limit): array
    {
        // ── 1. Exact law title match ──────────────────────────────────────────
        $results = $this->searchByExactTitle($rawQuery, $limit);
        if (!empty($results)) {
            Log::debug('LawRetrieverService: hit via exact title', ['query' => $rawQuery]);
            return $results;
        }

        // ── 2. Article number match — "მუხლი 37", "37-ე მუხლი" ───────────────
        $results = $this->searchByArticleNumber($rawQuery, $limit);
        if (!empty($results)) {
            Log::debug('LawRetrieverService: hit via article number', ['query' => $rawQuery]);
            return $results;
        }

        // ── 3. Keyword ILIKE search ───────────────────────────────────────────
        $results = $this->searchByKeyword($rawQuery, $limit);
        if (!empty($results)) {
            Log::debug('LawRetrieverService: hit via keyword', ['query' => $rawQuery]);
            return $results;
        }

        // ── 4. Vector embedding (semantic fallback) ───────────────────────────
        $results = $this->searchByVector($embedding, $limit);
        if (!empty($results)) {
            Log::debug('LawRetrieverService: hit via vector', ['query' => $rawQuery]);
            return $results;
        }

        // ── Miss → trigger on-demand fetch ────────────────────────────────────
        Log::debug('LawRetrieverService: no results', ['query' => $rawQuery]);
        $this->triggerOnDemandFetch($rawQuery);
        return [];
    }

    // ── Search strategies ─────────────────────────────────────────────────────

    private function searchByExactTitle(string $query, int $limit): array
    {
        $lower = mb_strtolower($query);

        // Match law title against known law name signals in the query
        $rows = DB::connection('pgvector')->select("
            SELECT
                la.id            AS article_id,
                la.law_id,
                la.article_num,
                la.article_title,
                la.content,
                la.chunk_index,
                1.0              AS similarity,
                l.title          AS law_title,
                l.source_url
            FROM   law_articles la
            JOIN   laws l ON l.id = la.law_id
            WHERE  l.status = 'active'
              AND  (
                     lower(l.title) = lower(:exact)
                  OR lower(:query) LIKE '%' || lower(l.title) || '%'
                  OR lower(l.title) LIKE '%' || lower(:query2) || '%'
              )
            ORDER  BY la.chunk_index ASC
            LIMIT  :limit
        ", [
            'exact'   => $query,
            'query'   => $lower,
            'query2'  => $lower,
            'limit'   => $limit * 3,
        ]);

        return $this->toResults($rows, $limit);
    }

    private function searchByArticleNumber(string $query, int $limit): array
    {
        // Extract "მუხლი N" or "N-ე მუხლი" patterns
        $articleNum = null;

        if (preg_match('/მუხლი\s+([\d]+)/u', $query, $m)) {
            $articleNum = 'მუხლი ' . $m[1];
        } elseif (preg_match('/([\d]+)[–-]?ე?\s*მუხლი/u', $query, $m)) {
            $articleNum = 'მუხლი ' . $m[1];
        }

        if (!$articleNum) return [];

        $rows = DB::connection('pgvector')->select("
            SELECT
                la.id            AS article_id,
                la.law_id,
                la.article_num,
                la.article_title,
                la.content,
                la.chunk_index,
                0.95             AS similarity,
                l.title          AS law_title,
                l.source_url
            FROM   law_articles la
            JOIN   laws l ON l.id = la.law_id
            WHERE  l.status = 'active'
              AND  la.article_num ILIKE :num
            ORDER  BY la.chunk_index ASC
            LIMIT  :limit
        ", [
            'num'   => '%' . $articleNum . '%',
            'limit' => $limit,
        ]);

        return $this->toResults($rows, $limit);
    }

    private function searchByKeyword(string $query, int $limit): array
    {
        if (mb_strlen($query) < 3) return [];

        // Extract meaningful terms — strip common stop words
        $terms = $this->extractSearchTerms($query);
        if (empty($terms)) return [];

        $rows = DB::connection('pgvector')->select("
            SELECT
                la.id            AS article_id,
                la.law_id,
                la.article_num,
                la.article_title,
                la.content,
                la.chunk_index,
                0.75             AS similarity,
                l.title          AS law_title,
                l.source_url
            FROM   law_articles la
            JOIN   laws l ON l.id = la.law_id
            WHERE  l.status = 'active'
              AND  (
                    la.content ILIKE :q1
                 OR la.article_title ILIKE :q2
              )
            ORDER  BY
                CASE WHEN la.article_title ILIKE :q3 THEN 0 ELSE 1 END,
                la.chunk_index ASC
            LIMIT  :limit
        ", [
            'q1'    => '%' . $terms . '%',
            'q2'    => '%' . $terms . '%',
            'q3'    => '%' . $terms . '%',
            'limit' => $limit * 2,
        ]);

        return $this->toResults($rows, $limit);
    }

    private function searchByVector(array $embedding, int $limit): array
    {
        if (empty($embedding)) return [];

        $vec  = '[' . implode(',', $embedding) . ']';
        $rows = [];

        foreach (self::VECTOR_THRESHOLDS as $threshold) {
            $rows = DB::connection('pgvector')->select("
                SELECT
                    la.id            AS article_id,
                    la.law_id,
                    la.article_num,
                    la.article_title,
                    la.content,
                    la.chunk_index,
                    1 - (la.embedding <=> :emb::vector) AS similarity,
                    l.title          AS law_title,
                    l.source_url
                FROM   law_articles la
                JOIN   laws l ON l.id = la.law_id
                WHERE  l.status = 'active'
                  AND  la.embedding IS NOT NULL
                  AND  1 - (la.embedding <=> :emb2::vector) >= :threshold
                ORDER  BY similarity DESC
                LIMIT  :chunk_limit
            ", [
                'emb'         => $vec,
                'emb2'        => $vec,
                'threshold'   => $threshold,
                'chunk_limit' => self::CHUNK_LIMIT,
            ]);

            if (!empty($rows)) break;
        }

        return $this->toResults($rows, $limit);
    }

    // ── Result building ───────────────────────────────────────────────────────

    /**
     * Deduplicate by law, keep best-scoring article per law, return top $limit.
     */
    private function toResults(array $rows, int $limit): array
    {
        if (empty($rows)) return [];

        // Best article per law
        $byLaw = [];
        foreach ($rows as $row) {
            $lid = $row->law_id;
            if (!isset($byLaw[$lid]) || (float) $row->similarity > (float) $byLaw[$lid]->similarity) {
                $byLaw[$lid] = $row;
            }
        }

        usort($byLaw, fn($a, $b) => (float) $b->similarity <=> (float) $a->similarity);

        return array_map(fn($row) => new LawResult(
            lawId:        $row->law_id,
            articleId:    $row->article_id,
            title:        $row->law_title,
            articleNum:   $row->article_num   ?? '',
            articleTitle: $row->article_title ?? '',
            excerpt:      mb_substr($row->content, 0, 800),
            similarity:   round((float) $row->similarity, 4),
            sourceUrl:    $row->source_url ?? '',
        ), array_slice($byLaw, 0, $limit));
    }

    // ── On-demand fetch ───────────────────────────────────────────────────────

    private function triggerOnDemandFetch(string $rawQuery): void
    {
        $matsneId = $this->matsne->resolveId($rawQuery);
        if (!$matsneId) return;

        // Already in DB?
        $exists = DB::connection('pgvector')
            ->table('laws')
            ->where('matsne_id', (string) $matsneId)
            ->exists();
        if ($exists) return;

        // Already queued or being fetched?
        if ($this->fetchLock->isQueued($matsneId) || $this->fetchLock->isLocked($matsneId)) {
            Log::debug('LawRetrieverService: fetch already in progress', ['matsne_id' => $matsneId]);
            return;
        }

        $this->fetchLock->markQueued($matsneId);
        FetchMatsneLawJob::dispatch($matsneId, $rawQuery)->onQueue('matsne-fetch');

        Log::info('LawRetrieverService: fetch dispatched', [
            'matsne_id' => $matsneId,
            'query'     => $rawQuery,
        ]);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function extractSearchTerms(string $query): string
    {
        $stopWords = [
            'რა', 'რომ', 'და', 'ან', 'მე', 'შენ', 'ის', 'ჩვენ', 'თქვენ', 'ისინი',
            'ამბობს', 'ამბობ', 'ვიცი', 'მინდა', 'მომეცი', 'ახსენი', 'გამიხსენი',
            'შესახებ', 'ზედ', 'ზე', 'ში', 'ით', 'ად', 'თვის', 'გამო',
        ];

        $words = preg_split('/\s+/u', mb_strtolower(trim($query)));
        $meaningful = array_filter($words, fn($w) =>
            mb_strlen($w) >= 3 && !in_array($w, $stopWords)
        );

        return implode(' ', array_slice(array_values($meaningful), 0, 3));
    }
}
