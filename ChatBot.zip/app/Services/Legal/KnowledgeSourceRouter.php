<?php

namespace App\Services\Legal;

use App\DTOs\SourcePlan;

class KnowledgeSourceRouter
{
    /**
     * Keywords that signal the user is asking about legislation/statutes.
     * If any of these appear in the query, we also search law_articles.
     */
    private const LAW_SIGNALS = [
        'კანონი',
        'კოდექსი',
        'მუხლი',
        'დადგენილება',
        'კანონმდებლობა',
        'ნორმა',
        'რეგულაცია',
        'სამოქალაქო კოდექსი',
        'ადმინისტრაციული საპროცესო',
        'საგადასახადო კოდექსი',
        'ზოგადი ადმინისტრაციული',
        'სისხლის სამართლის',
        'სამართლებრივი ნორმა',
        'კანონის მიხედვით',
        'კანონის თანახმად',
        'კანონდარღვევა',
    ];

    public function plan(string $query): SourcePlan
    {
        $lower   = mb_strtolower($query);
        $useLaw  = $this->matchesAny($lower, self::LAW_SIGNALS);

        // Always search domestic cases unless it's a pure law-text lookup
        // (e.g. "მიმეცი საგადასახადო კოდექსის მე-5 მუხლის ტექსტი")
        $useDomestic = !$this->isPureLawTextLookup($lower);

        return new SourcePlan(
            useDomestic: $useDomestic,
            useLaw:      $useLaw,
        );
    }

    private function matchesAny(string $text, array $signals): bool
    {
        foreach ($signals as $signal) {
            if (str_contains($text, mb_strtolower($signal))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Detects queries that ask for the verbatim text of a law article,
     * where searching court decisions adds little value.
     */
    private function isPureLawTextLookup(string $lower): bool
    {
        $pureLawPhrases = [
            'მომეცი კანონის ტექსტი',
            'მიმეცი კანონის ტექსტი',
            'კანონის სრული ტექსტი',
            'მუხლის ტექსტი',
            'ჩამოჩამოწერე მუხლი',
        ];

        return $this->matchesAny($lower, $pureLawPhrases);
    }
}
