<?php

namespace App\DTOs;

readonly class SourcePlan
{
    public function __construct(
        public bool $useDomestic,
        public bool $useLaw,
    ) {}

    public function isHybrid(): bool
    {
        return $this->useDomestic && $this->useLaw;
    }
}
